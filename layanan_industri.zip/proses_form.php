<?php
session_start();
include 'db.php'; // File ini harus memuat koneksi ke database ($conn)

// Ambil data dari form
$email    = $_POST['email'] ?? '';
$tanggal  = $_POST['date'] ?? '';
$nama     = $_POST['nama'] ?? '';
$phone    = $_POST['phone'] ?? '';
$alamat   = $_POST['alamat'] ?? '';

// Validasi tanggal kosong atau tidak valid
if (empty($tanggal)) {
    $_SESSION['messages'][] = ['text' => 'Tanggal tidak boleh kosong.', 'category' => 'error'];
    header("Location: form.php");
    exit();
}
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $tanggal)) {
    $_SESSION['messages'][] = ['text' => 'Format tanggal tidak valid (harus YYYY-MM-DD).', 'category' => 'error'];
    header("Location: form.php");
    exit();
}

$jenis_ikm = ($_POST['ikm_type'] === 'Lainnya') ? '-' : $_POST['ikm_type'];
$ikm_type_other = ($_POST['ikm_type'] === 'Lainnya') ? $_POST['ikm_type_other'] : null;

$keperluan = ($_POST['purpose'] === 'Lainnya') ? '-' : $_POST['purpose'];
$purpose_other = ($_POST['purpose'] === 'Lainnya') ? $_POST['purpose_other'] : null;


// Penanganan upload file
$file_path = null;
if (isset($_FILES['file']) && $_FILES['file']['error'] === UPLOAD_ERR_OK) {
    $upload_dir = 'uploads/';
    if (!is_dir($upload_dir)) mkdir($upload_dir, 0777, true);

    $filename = time() . '_' . basename($_FILES['file']['name']);
    $target_path = $upload_dir . $filename;

    if (move_uploaded_file($_FILES['file']['tmp_name'], $target_path)) {
        $file_path = $target_path;
    } else {
        $_SESSION['messages'][] = ['text' => 'Gagal mengunggah file.', 'category' => 'error'];
        header("Location: form.php");
        exit();
    }
}

// Simpan ke database
$stmt = $conn->prepare("INSERT INTO form 
    (email, tanggal, nama, phone, alamat, jenis_ikm, ikm_type_other, keperluan, purpose_other, file_path) 
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("ssssssssss", $email, $tanggal, $nama, $phone, $alamat, $jenis_ikm, $ikm_type_other, $keperluan, $purpose_other, $file_path);

if ($stmt->execute()) {
    $_SESSION['messages'][] = ['text' => 'Data berhasil disimpan!', 'category' => 'success'];
    header("Location: thankyou.php"); // Ubah ke terima_kasih.php jika itu nama file suksesmu
    exit();
} else {
    $_SESSION['messages'][] = ['text' => 'Gagal menyimpan data: ' . $stmt->error, 'category' => 'error'];
    header("Location: form.php");
    exit();
}
?>
