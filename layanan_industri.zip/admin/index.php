<?php
session_start();
require '../db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$current_year = date('Y');

$bulan_nama = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
$monthly_data = [];
for ($i = 1; $i <= 12; $i++) {
    $monthly_data[$i] = ['bulan' => $bulan_nama[$i-1], 'jumlah' => 0];
}
$stmt = mysqli_prepare($conn, "
    SELECT MONTH(tanggal) as bulan, COUNT(*) as jumlah_tamu 
    FROM form WHERE YEAR(tanggal)=? GROUP BY MONTH(tanggal)
");
mysqli_stmt_bind_param($stmt, "i", $current_year);
mysqli_stmt_execute($stmt);
$res = mysqli_stmt_get_result($stmt);
while ($row = mysqli_fetch_assoc($res)) {
    $monthly_data[$row['bulan']] = [
        'bulan' => $bulan_nama[$row['bulan']-1],
        'jumlah' => (int)$row['jumlah_tamu']
    ];
}
mysqli_stmt_close($stmt);

$total_tamu = (int)mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM form"))['total'];
$tamu_bulan_ini = (int)mysqli_fetch_assoc(mysqli_query($conn, "
    SELECT COUNT(*) as total FROM form WHERE MONTH(tanggal)=MONTH(CURDATE()) AND YEAR(tanggal)=YEAR(CURDATE())
"))['total'];

$ikm_data = [];
$res = mysqli_query($conn, "SELECT jenis_ikm, COUNT(*) as jumlah FROM form WHERE jenis_ikm!='' GROUP BY jenis_ikm ORDER BY jumlah DESC LIMIT 5");
while ($row = mysqli_fetch_assoc($res)) $ikm_data[] = $row;

$keperluan_data = [];
$res = mysqli_query($conn, "SELECT keperluan, COUNT(*) as jumlah FROM form WHERE keperluan!='' GROUP BY keperluan ORDER BY jumlah DESC LIMIT 5");
while ($row = mysqli_fetch_assoc($res)) $keperluan_data[] = $row;
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Dashboard Admin</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSS -->
    <link href="static/style.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">

    <!-- JS -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>

<body>
<div class="container py-4">

    <!-- Header & Icon -->
<div class="dashboard-header">
    <img src="static/img/logo.png" alt="Logo" style="height: 60px;">
    <h1>Selamat datang di dashboard admin</h1>
</div>


    <!-- Navigasi -->
    <div class="btn-group mb-4 d-flex flex-wrap" role="group">
        <a href="admin.php" class="btn btn-secondary"><i class="fas fa-table"></i> Data Formulir</a>
        <a href="export_excel.php" class="btn btn-success"><i class="fas fa-file-excel"></i> Export Excel</a>
        <a href="export_word.php" class="btn btn-info"><i class="fas fa-file-word"></i> Export Word</a>
        <a href="admin_tim.php" class="btn btn-warning"><i class="fas fa-users-cog"></i> Input Tim</a>
        <a href="logout.php" class="btn btn-danger"><i class="fas fa-sign-out-alt"></i> Logout</a>
    </div>

    <!-- Statistik -->
    <div class="row mb-4">
        <div class="col-md-6">
            <div class="card card-stats shadow-sm mb-3">
                <div class="card-body d-flex justify-content-between align-items-center">
                    <div>
                        <div class="text-uppercase small">Total Tamu</div>
                        <h4><?= number_format($total_tamu) ?></h4>
                    </div>
                    <i class="fas fa-users fa-2x"></i>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card card-stats-2 shadow-sm mb-3">
                <div class="card-body d-flex justify-content-between align-items-center">
                    <div>
                        <div class="text-uppercase small">Tamu Bulan Ini</div>
                        <h4><?= number_format($tamu_bulan_ini) ?></h4>
                    </div>
                    <i class="fas fa-calendar-alt fa-2x"></i>
                </div>
            </div>
        </div>
    </div>

    <!-- Grafik dan Data Populer -->
    <div class="row">
        <div class="col-md-6">
            <div class="card shadow-sm mb-4">
                <div class="card-header"><strong>Statistik Tamu per Bulan</strong></div>
                <div class="card-body">
                    <div class="chart-container">
                        <canvas id="monthlyChart"></canvas>
                    </div>
                </div>
            </div>
        </div>

        <!-- Jenis IKM dan Keperluan -->
        <div class="col-md-6">
            <div class="row">
                <div class="col-12 mb-3">
                    <div class="card shadow-sm">
                        <div class="card-header"><strong>Jenis IKM Terpopuler</strong></div>
                        <div class="card-body">
                            <?php if (empty($ikm_data)): ?>
                                <p class="text-muted">Belum ada data.</p>
                            <?php else: ?>
                                <table class="table table-sm">
                                    <?php foreach ($ikm_data as $i => $row): ?>
                                        <tr>
                                            <td><span class="badge bg-primary"><?= $i+1 ?></span></td>
                                            <td><?= htmlspecialchars($row['jenis_ikm']) ?></td>
                                            <td class="text-end"><span class="badge bg-success"><?= $row['jumlah'] ?></span></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </table>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="col-12">
                    <div class="card shadow-sm">
                        <div class="card-header"><strong>Keperluan Terpopuler</strong></div>
                        <div class="card-body">
                            <?php if (empty($keperluan_data)): ?>
                                <p class="text-muted">Belum ada data.</p>
                            <?php else: ?>
                                <table class="table table-sm">
                                    <?php foreach ($keperluan_data as $i => $row): ?>
                                        <tr>
                                            <td><span class="badge bg-primary"><?= $i+1 ?></span></td>
                                            <td><?= htmlspecialchars($row['keperluan']) ?></td>
                                            <td class="text-end"><span class="badge bg-success"><?= $row['jumlah'] ?></span></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </table>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Grafik Chart.js -->
<script>
const monthlyData = <?= json_encode(array_values($monthly_data)) ?>;
new Chart(document.getElementById('monthlyChart'), {
    type: 'line',
    data: {
        labels: monthlyData.map(d => d.bulan),
        datasets: [{
            label: 'Jumlah Tamu',
            data: monthlyData.map(d => d.jumlah),
            borderColor: 'rgb(75, 192, 192)',
            backgroundColor: 'rgba(75, 192, 192, 0.2)',
            borderWidth: 2,
            fill: true,
            tension: 0.3
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
            y: { beginAtZero: true }
        }
    }
});
</script>
</body>
</html>
