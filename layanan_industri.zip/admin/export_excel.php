<?php
// Clear any previous output
if (ob_get_level()) {
    ob_end_clean();
}

require '../db.php';
require 'vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Worksheet\Drawing;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Style\Border;

try {
    if (!$conn) {
        throw new Exception("Database connection failed: " . mysqli_connect_error());
    }

    // 🔎 --- Filter Tahun ---
    $where = "";
    if (!empty($_GET['tahun_id'])) {
        $tahun_id = intval($_GET['tahun_id']);
        $where = "WHERE form.tahun_id = $tahun_id";
    }

    // 🔎 --- Query Data ---
    $query = "
        SELECT form.*, tahun_kategori.tahun
        FROM form
        LEFT JOIN tahun_kategori ON form.tahun_id = tahun_kategori.id
        $where
        ORDER BY form.id ASC
    ";
    $result = mysqli_query($conn, $query);

    if (!$result) {
        throw new Exception("Query failed: " . mysqli_error($conn));
    }

    if (mysqli_num_rows($result) == 0) {
        throw new Exception("Tidak ada data untuk diekspor");
    }

    // 📝 --- Buat Spreadsheet ---
    $spreadsheet = new Spreadsheet();
    $sheet = $spreadsheet->getActiveSheet();
    $sheet->setTitle('Data Formulir');

    // Header
    $headers = [
        'A1' => 'No',
        'B1' => 'Tahun',
        'C1' => 'Email',
        'D1' => 'Tanggal',
        'E1' => 'Nama',
        'F1' => 'Alamat',
        'G1' => 'Telepon',
        'H1' => 'Jenis IKM',
        'I1' => 'Lainnya (IKM)',
        'J1' => 'Keperluan',
        'K1' => 'Lainnya (Keperluan)',
        'L1' => 'Bukti'
    ];
    foreach ($headers as $cell => $value) {
        $sheet->setCellValue($cell, $value);
    }

    // Style header
    $headerStyle = [
        'font' => [
            'bold' => true,
            'size' => 12,
            'color' => ['rgb' => 'FFFFFF']
        ],
        'fill' => [
            'fillType' => Fill::FILL_SOLID,
            'color' => ['rgb' => '4F46E5']
        ],
        'borders' => [
            'allBorders' => [
                'borderStyle' => Border::BORDER_THIN,
                'color' => ['rgb' => '374151']
            ]
        ],
        'alignment' => [
            'horizontal' => Alignment::HORIZONTAL_CENTER,
            'vertical' => Alignment::VERTICAL_CENTER
        ]
    ];
    $sheet->getStyle('A1:L1')->applyFromArray($headerStyle);
    $sheet->getRowDimension(1)->setRowHeight(30);

    // Isi data
    $rowNum = 2;
    $no = 1;
    while ($row = mysqli_fetch_assoc($result)) {
        $sheet->setCellValue("A{$rowNum}", $no++);
        $sheet->setCellValue("B{$rowNum}", $row['tahun'] ?? '-');
        $sheet->setCellValue("C{$rowNum}", $row['email'] ?? '');
        $sheet->setCellValue("D{$rowNum}", $row['tanggal'] ?? '');
        $sheet->setCellValue("E{$rowNum}", $row['nama'] ?? '');
        $sheet->setCellValue("F{$rowNum}", $row['alamat'] ?? '');
        $sheet->setCellValue("G{$rowNum}", $row['phone'] ?? '');
        $sheet->setCellValue("H{$rowNum}", $row['jenis_ikm'] ?? '');
        $sheet->setCellValue("I{$rowNum}", $row['ikm_type_other'] ?? '');
        $sheet->setCellValue("J{$rowNum}", $row['keperluan'] ?? '');
        $sheet->setCellValue("K{$rowNum}", $row['purpose_other'] ?? '');

        // Cek file
        $filePath = $row['file_path'] ?? '';
        if (!empty($filePath) && file_exists($filePath)) {
            $ext = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));
            $isImage = in_array($ext, ['jpg','jpeg','png','gif','webp']);
            if ($isImage) {
                $drawing = new Drawing();
                $drawing->setPath($filePath);
                $drawing->setCoordinates("L{$rowNum}");
                $drawing->setHeight(50);
                $drawing->setWidth(70);
                $drawing->setOffsetX(5);
                $drawing->setOffsetY(5);
                $drawing->setWorksheet($sheet);
                $sheet->getRowDimension($rowNum)->setRowHeight(55);
            } else {
                $sheet->setCellValue("L{$rowNum}", basename($filePath));
            }
        } else {
            $sheet->setCellValue("L{$rowNum}", '-');
        }
        $rowNum++;
    }

    // Styling data
    $lastRow = $rowNum - 1;
    $dataStyle = [
        'borders' => [
            'allBorders' => [
                'borderStyle' => Border::BORDER_THIN,
                'color' => ['rgb' => 'D1D5DB']
            ]
        ],
        'alignment' => [
            'vertical' => Alignment::VERTICAL_CENTER,
            'wrapText' => true
        ]
    ];
    $sheet->getStyle("A2:L{$lastRow}")->applyFromArray($dataStyle);

    // Zebra striping
    for ($i = 2; $i <= $lastRow; $i++) {
        if ($i % 2 == 0) {
            $sheet->getStyle("A{$i}:L{$i}")->applyFromArray([
                'fill' => [
                    'fillType' => Fill::FILL_SOLID,
                    'color' => ['rgb' => 'F8FAFC']
                ]
            ]);
        }
    }

    // Column width
    $colWidths = [
        'A'=>5,'B'=>10,'C'=>25,'D'=>12,'E'=>20,'F'=>30,'G'=>15,
        'H'=>15,'I'=>15,'J'=>20,'K'=>20,'L'=>15
    ];
    foreach ($colWidths as $col => $width) {
        $sheet->getColumnDimension($col)->setWidth($width);
    }
    $sheet->freezePane('B2');

    // Info export
    $totalRows = $rowNum-2;
    $infoStart = $rowNum + 2;
    $sheet->setCellValue("A{$infoStart}", "INFORMASI EXPORT");
    $sheet->mergeCells("A{$infoStart}:L{$infoStart}");
    $sheet->getStyle("A{$infoStart}:L{$infoStart}")->applyFromArray([
        'font'=>['bold'=>true,'size'=>11,'color'=>['rgb'=>'374151']],
        'fill'=>['fillType'=>Fill::FILL_SOLID,'color'=>['rgb'=>'E5E7EB']],
        'alignment'=>['horizontal'=>Alignment::HORIZONTAL_CENTER]
    ]);

    $sheet->setCellValue("A".($infoStart+1), "Total Data:");
    $sheet->setCellValue("B".($infoStart+1), "$totalRows records");
    $sheet->setCellValue("A".($infoStart+2), "Tanggal Export:");
    $sheet->setCellValue("B".($infoStart+2), date('d F Y, H:i:s'));
    $sheet->setCellValue("A".($infoStart+3), "Exported by:");
    $sheet->setCellValue("B".($infoStart+3), "Sistem Pendaftaran Tamu - Bidang Industri");

    $sheet->getStyle("A".($infoStart+1).":B".($infoStart+3))->applyFromArray([
        'font'=>['size'=>9,'italic'=>true,'color'=>['rgb'=>'6B7280']]
    ]);
    $sheet->getStyle("A".($infoStart+1).":A".($infoStart+3))->getFont()->setBold(true);

    // Output
    while (ob_get_level()) ob_end_clean();
    $filename = "data_formulir_".date('Y-m-d_H-i-s').".xlsx";
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment;filename="'.$filename.'"');
    header('Cache-Control: max-age=0');
    $writer = new Xlsx($spreadsheet);
    $writer->save('php://output');

} catch (Exception $e) {
    while (ob_get_level()) ob_end_clean();
    echo "<h2>Export Gagal</h2><p>Error: ".htmlspecialchars($e->getMessage())."</p>";
} finally {
    if (isset($result)) mysqli_free_result($result);
    if (isset($conn)) mysqli_close($conn);
    if (isset($spreadsheet)) {
        $spreadsheet->disconnectWorksheets();
        unset($spreadsheet);
    }
}
exit;
?>
