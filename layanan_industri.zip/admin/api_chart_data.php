<?php
session_start();
require 'db.php';

// Pastikan hanya admin yang bisa akses
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit();
}

header('Content-Type: application/json');

$type = $_GET['type'] ?? 'monthly';
$year = $_GET['year'] ?? date('Y');

switch ($type) {
    case 'monthly':
        // Data pengunjung per bulan
        $query = "
            SELECT 
                MONTH(tanggal) as bulan,
                COUNT(*) as jumlah_tamu,
                MONTHNAME(tanggal) as nama_bulan
            FROM form 
            WHERE YEAR(tanggal) = $year
            GROUP BY YEAR(tanggal), MONTH(tanggal)
            ORDER BY MONTH(tanggal)
        ";
        
        $result = mysqli_query($conn, $query);
        $monthly_data = [];
        $bulan_nama = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        
        // Inisialisasi dengan 0
        for ($i = 1; $i <= 12; $i++) {
            $monthly_data[] = ['bulan' => $bulan_nama[$i-1], 'jumlah' => 0];
        }
        
        // Isi data yang ada
        while ($row = mysqli_fetch_assoc($result)) {
            $monthly_data[$row['bulan']-1] = [
                'bulan' => $bulan_nama[$row['bulan']-1], 
                'jumlah' => (int)$row['jumlah_tamu']
            ];
        }
        
        echo json_encode($monthly_data);
        break;
    
    case 'ikm':
        // Data jenis IKM terpopuler
        $query = "
            SELECT jenis_ikm, COUNT(*) as jumlah 
            FROM form 
            WHERE jenis_ikm != '' AND jenis_ikm IS NOT NULL
            AND YEAR(tanggal) = $year
            GROUP BY jenis_ikm 
            ORDER BY jumlah DESC 
            LIMIT 10
        ";
        
        $result = mysqli_query($conn, $query);
        $data = [];
        while ($row = mysqli_fetch_assoc($result)) {
            $data[] = [
                'label' => $row['jenis_ikm'],
                'jumlah' => (int)$row['jumlah']
            ];
        }
        
        echo json_encode($data);
        break;
    
    case 'keperluan':
        // Data keperluan terpopuler
        $query = "
            SELECT keperluan, COUNT(*) as jumlah 
            FROM form 
            WHERE keperluan != '' AND keperluan IS NOT NULL
            AND YEAR(tanggal) = $year
            GROUP BY keperluan 
            ORDER BY jumlah DESC 
            LIMIT 10
        ";
        
        $result = mysqli_query($conn, $query);
        $data = [];
        while ($row = mysqli_fetch_assoc($result)) {
            $data[] = [
                'label' => $row['keperluan'],
                'jumlah' => (int)$row['jumlah']
            ];
        }
        
        echo json_encode($data);
        break;
    
    case 'stats':
        // Statistik umum
        $total_query = "SELECT COUNT(*) as total FROM form";
        $total_result = mysqli_query($conn, $total_query);
        $total = mysqli_fetch_assoc($total_result)['total'];
        
        $bulan_ini_query = "SELECT COUNT(*) as total FROM form WHERE MONTH(tanggal) = MONTH(CURDATE()) AND YEAR(tanggal) = YEAR(CURDATE())";
        $bulan_ini_result = mysqli_query($conn, $bulan_ini_query);
        $bulan_ini = mysqli_fetch_assoc($bulan_ini_result)['total'];
        
        $hari_ini_query = "SELECT COUNT(*) as total FROM form WHERE DATE(tanggal) = CURDATE()";
        $hari_ini_result = mysqli_query($conn, $hari_ini_query);
        $hari_ini = mysqli_fetch_assoc($hari_ini_result)['total'];
        
        $minggu_ini_query = "SELECT COUNT(*) as total FROM form WHERE YEARWEEK(tanggal) = YEARWEEK(CURDATE())";
        $minggu_ini_result = mysqli_query($conn, $minggu_ini_query);
        $minggu_ini = mysqli_fetch_assoc($minggu_ini_result)['total'];
        
        echo json_encode([
            'total' => (int)$total,
            'bulan_ini' => (int)$bulan_ini,
            'hari_ini' => (int)$hari_ini,
            'minggu_ini' => (int)$minggu_ini
        ]);
        break;
    
    case 'weekly':
        // Data pengunjung per minggu dalam bulan ini
        $query = "
            SELECT 
                WEEK(tanggal) - WEEK(DATE_SUB(tanggal, INTERVAL DAYOFMONTH(tanggal)-1 DAY)) + 1 as minggu,
                COUNT(*) as jumlah
            FROM form 
            WHERE MONTH(tanggal) = MONTH(CURDATE()) 
            AND YEAR(tanggal) = YEAR(CURDATE())
            GROUP BY minggu
            ORDER BY minggu
        ";
        
        $result = mysqli_query($conn, $query);
        $data = [];
        for ($i = 1; $i <= 5; $i++) {
            $data[] = ['minggu' => "Minggu $i", 'jumlah' => 0];
        }
        
        while ($row = mysqli_fetch_assoc($result)) {
            if ($row['minggu'] >= 1 && $row['minggu'] <= 5) {
                $data[$row['minggu']-1] = [
                    'minggu' => "Minggu " . $row['minggu'],
                    'jumlah' => (int)$row['jumlah']
                ];
            }
        }
        
        echo json_encode($data);
        break;
    
    default:
        http_response_code(400);
        echo json_encode(['error' => 'Invalid type parameter']);
        break;
}
?>