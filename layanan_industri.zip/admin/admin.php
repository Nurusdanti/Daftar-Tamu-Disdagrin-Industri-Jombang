<?php
session_start();
require '../db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

// Proses hapus
if (isset($_POST['hapus'])) {
    if (!empty($_POST['selected_ids'])) {
        // Hapus yang dipilih
        $ids = implode(",", array_map('intval', $_POST['selected_ids']));
        mysqli_query($conn, "DELETE FROM form WHERE id IN ($ids)");
    } else {
        // Hapus semua
        mysqli_query($conn, "DELETE FROM form");
    }
    header("Location: admin.php");
    exit();
}

// Filter tahun
$tahunFilter = "";
$where = "";
if (isset($_GET['tahun_id']) && $_GET['tahun_id'] !== '') {
    $tahunFilter = intval($_GET['tahun_id']);
    $where = "WHERE tahun_id = $tahunFilter";
}

$query = "SELECT * FROM form $where ORDER BY id DESC";
$result = mysqli_query($conn, $query);

$daftarTahun = mysqli_query($conn, "SELECT * FROM tahun_kategori ORDER BY tahun ASC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard - Data Formulir</title>
    <link rel="stylesheet" href="static/admin.css">
</head>
<body>

<div class="container">
    <h2>📋 Data Formulir Masuk</h2>

    <!-- Tombol Kelola Tahun (satu saja) -->
    <div style="margin-bottom:10px;">
        <a href="admin_tahun.php" class="btn orange">📂 Kelola Tahun</a>
        <a href="export_excel.php?tahun_id=<?= $tahunFilter ?>" class="btn green">📄 Export Excel</a>
        <a href="export_word.php?tahun_id=<?= $tahunFilter ?>" class="btn purple">📝 Export Word</a>
        <a href="index.php" class="btn blue">⬅ Kembali ke Dashboard</a>
    </div>

    <form method="get" style="margin-top:10px; margin-bottom:10px;">
        <label for="tahun_id"><strong>Filter Tahun:</strong></label>
        <select name="tahun_id" onchange="this.form.submit()">
            <option value="">-- Semua Tahun --</option>
            <?php while ($t = mysqli_fetch_assoc($daftarTahun)): ?>
                <option value="<?= $t['id'] ?>" <?= ($tahunFilter==$t['id']?'selected':'') ?>>
                    <?= $t['tahun'] ?>
                </option>
            <?php endwhile; ?>
        </select>
    </form>

    <input type="text" id="searchInput" placeholder="🔍 Cari nama, email, alamat..." onkeyup="searchTable()">

    <form method="post" id="bulkForm" onsubmit="return confirm('Yakin ingin menghapus data? Jika memilih data tertentu akan menghapus data tersebut, jika tidak memilih akan menghapus semua.');">
        <div class="bulk-actions">
            <!-- Satu tombol untuk dua fungsi -->
            <button type="submit" name="hapus" class="btn red">🗑️ Hapus</button>
        </div>

        <div class="table-container">
            <table id="dataTable">
                <thead>
                    <tr>
                        <th><input type="checkbox" id="selectAll"></th>
                        <th>No</th>
                        <th>Email</th>
                        <th>Tanggal</th>
                        <th>Nama</th>
                        <th>Alamat</th>
                        <th>Telepon</th>
                        <th>Jenis IKM</th>
                        <th>Lainnya (IKM)</th>
                        <th>Keperluan</th>
                        <th>Lainnya (Keperluan)</th>
                        <th>Bukti</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $no = 1; while ($entry = mysqli_fetch_assoc($result)): ?>
                    <tr>
                        <td><input type="checkbox" name="selected_ids[]" value="<?= $entry['id'] ?>"></td>
                        <td><?= $no++ ?></td>
                        <td><?= htmlspecialchars($entry['email']) ?></td>
                        <td><?= htmlspecialchars($entry['tanggal']) ?></td>
                        <td><?= htmlspecialchars($entry['nama']) ?></td>
                        <td><?= htmlspecialchars($entry['alamat']) ?></td>
                        <td><?= htmlspecialchars($entry['phone']) ?></td>
                        <td><?= htmlspecialchars($entry['jenis_ikm']) ?></td>
                        <td><?= htmlspecialchars($entry['ikm_type_other'] ?: '-') ?></td>
                        <td><?= htmlspecialchars($entry['keperluan']) ?></td>
                        <td><?= htmlspecialchars($entry['purpose_other'] ?: '-') ?></td>
                        <td>
                            <?php
                            if (!empty($entry['file_path'])):
                                $ext = strtolower(pathinfo($entry['file_path'], PATHINFO_EXTENSION));
                                $isImage = in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp']);
                                if ($isImage):
                                    echo '<img src="' . htmlspecialchars($entry['file_path']) . '" width="80">';
                                else:
                                    echo '<a href="' . htmlspecialchars($entry['file_path']) . '" target="_blank">Lihat</a>';
                                endif;
                            else:
                                echo '<span style="color: gray;">-</span>';
                            endif;
                            ?>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </form>
</div>

<script>
function searchTable() {
    const input = document.getElementById("searchInput").value.toLowerCase();
    const rows = document.querySelectorAll("#dataTable tbody tr");
    rows.forEach(row => {
        row.style.display = row.innerText.toLowerCase().includes(input) ? "" : "none";
    });
}

document.getElementById("selectAll").addEventListener("change", function () {
    const checkboxes = document.querySelectorAll("input[name='selected_ids[]']");
    checkboxes.forEach(cb => cb.checked = this.checked);
});
</script>

</body>
</html>
