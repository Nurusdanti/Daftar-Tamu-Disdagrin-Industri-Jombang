<?php
session_start();
require '../db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'])) {
    $id = intval($_POST['id']);

    // Cek dan hapus file bukti jika ada
    $query = "SELECT file_path FROM form WHERE id = $id";
    $result = mysqli_query($conn, $query);
    if ($row = mysqli_fetch_assoc($result)) {
        $file_path = $row['file_path'];
        if (!empty($file_path) && file_exists($file_path)) {
            unlink($file_path); // hapus file dari server
        }
    }

    // Hapus data dari database
    $deleteQuery = "DELETE FROM form WHERE id = $id";
    mysqli_query($conn, $deleteQuery);
}

header("Location: admin.php"); // kembali ke dashboard
exit();
