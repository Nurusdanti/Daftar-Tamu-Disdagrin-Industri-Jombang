<?php include '../db.php'; ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Kelola Kategori Tahun</title>
    <link rel="stylesheet" href="static/admin_tahun.css" />
</head>
<body>

<h2>Kelola Kategori Tahun</h2>
<p>
    <a href="index.php" style="display:inline-block; padding:8px 15px; background:#007bff; color:#fff; text-decoration:none; border-radius:4px; margin-bottom:15px;">
        &larr; Kembali ke Dashboard
    </a>
</p>

<!-- Form tambah tahun baru -->
<form method="post">
    <input type="number" name="tahun" placeholder="Tahun baru" required>
    <button type="submit" name="tambah">Tambah</button>
</form>
<br>

<?php
// Proses tambah data tahun
if(isset($_POST['tambah'])){
    $tahun = intval($_POST['tahun']);
    mysqli_query($conn, "INSERT INTO tahun_kategori (tahun) VALUES ('$tahun')");
    header("Location: admin_tahun.php");
    exit;
}

// Proses hapus data tahun
if(isset($_GET['hapus'])){
    $id = intval($_GET['hapus']);
    mysqli_query($conn, "DELETE FROM tahun_kategori WHERE id=$id");
    header("Location: admin_tahun.php");
    exit;
}

// Proses edit data tahun
if(isset($_POST['edit'])){
    $id = intval($_POST['id']);
    $tahun = intval($_POST['tahun']);
    mysqli_query($conn, "UPDATE tahun_kategori SET tahun='$tahun' WHERE id=$id");
    header("Location: admin_tahun.php");
    exit;
}
?>

<!-- Tabel daftar tahun -->
<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>Tahun</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
    <?php
    $q = mysqli_query($conn, "SELECT * FROM tahun_kategori ORDER BY tahun ASC");
    while($row = mysqli_fetch_assoc($q)){
        echo "<tr>
            <td>{$row['id']}</td>
            <td>{$row['tahun']}</td>
            <td>
                <form method='post' style='display:inline'>
                    <input type='hidden' name='id' value='{$row['id']}'>
                    <input type='number' name='tahun' value='{$row['tahun']}' required>
                    <button type='submit' name='edit'>Edit</button>
                </form>
                <a href='?hapus={$row['id']}' onclick='return confirm(\"Hapus?\")' style='color:red; margin-left:10px;'>Hapus</a>
            </td>
        </tr>";
    }
    ?>
    </tbody>
</table>

</body>
</html>
