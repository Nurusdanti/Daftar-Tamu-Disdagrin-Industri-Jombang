<?php
require 'vendor/autoload.php';
require '../db.php';

use PhpOffice\PhpWord\PhpWord;
use PhpOffice\PhpWord\IOFactory;
use PhpOffice\PhpWord\Shared\Converter;
use PhpOffice\PhpWord\SimpleType\Jc;

// Bersihkan buffer output
if (ob_get_level()) ob_end_clean();

header("Content-Type: application/vnd.openxmlformats-officedocument.wordprocessingml.document");
header("Content-Disposition: attachment; filename=\"data_formulir.docx\"");
header("Cache-Control: max-age=0");

// 🔎 Filter tahun
$where = "";
if (!empty($_GET['tahun_id'])) {
    $tahun_id = intval($_GET['tahun_id']);
    $where = "WHERE form.tahun_id = $tahun_id";
}

// 🔎 Query data dengan join
$sql = "
    SELECT form.*, tahun_kategori.tahun
    FROM form
    LEFT JOIN tahun_kategori ON form.tahun_id = tahun_kategori.id
    $where
    ORDER BY form.id DESC
";
$query = mysqli_query($conn, $sql);

// Jika tidak ada data
if (!$query || mysqli_num_rows($query) == 0) {
    echo "<h3>Tidak ada data untuk diekspor</h3>";
    exit;
}

// Buat objek Word
$phpWord = new PhpWord();

// Style tabel
$phpWord->addTableStyle('DataFormulirStyle', [
    'borderSize' => 6,
    'borderColor' => '999999',
    'cellMargin' => 80,
], [
    'borderBottomSize' => 6,
    'borderBottomColor' => '000000',
    'bgColor' => '1E40AF',
    'color' => 'FFFFFF',
    'bold' => true
]);

$section = $phpWord->addSection([
    'orientation' => 'landscape',
    'marginTop' => Converter::cmToTwip(1.5),
    'marginBottom' => Converter::cmToTwip(1.5),
    'marginLeft' => Converter::cmToTwip(1.5),
    'marginRight' => Converter::cmToTwip(1.5),
]);

// Judul
$section->addText('DAFTAR TAMU', [
    'bold' => true,
    'size' => 18,
    'name' => 'Arial',
], ['alignment' => Jc::CENTER]);

// Tanggal export
$section->addText('Tanggal Export: ' . date('d-m-Y'), [
    'italic' => true,
    'size' => 10,
], ['alignment' => Jc::CENTER]);

$section->addTextBreak(1);

// Buat tabel
$table = $section->addTable('DataFormulirStyle');

// Header tabel
$headers = ['No', 'Tahun', 'Email', 'Nama', 'Tanggal', 'Alamat', 'Bukti'];
$table->addRow();
foreach ($headers as $head) {
    $table->addCell(Converter::cmToTwip(4))->addText($head, [
        'bold' => true,
        'color' => 'FFFFFF',
    ]);
}

// Isi data
$no = 1;
while ($row = mysqli_fetch_assoc($query)) {
    $table->addRow();

    $table->addCell(Converter::cmToTwip(2))->addText($no++);
    $table->addCell(Converter::cmToTwip(2))->addText($row['tahun'] ?: '-');
    $table->addCell(Converter::cmToTwip(4))->addText($row['email'] ?: '-');
    $table->addCell(Converter::cmToTwip(4))->addText($row['nama'] ?: '-');
    $table->addCell(Converter::cmToTwip(3))->addText($row['tanggal'] ?: '-');
    $table->addCell(Converter::cmToTwip(6))->addText($row['alamat'] ?: '-');

    // Gambar bukti
    $filePath = $row['file_path'];
    $ext = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));
    if (!empty($filePath) && in_array($ext, ['jpg', 'jpeg', 'png']) && file_exists($filePath)) {
        try {
            $table->addCell(Converter::cmToTwip(4))->addImage($filePath, [
                'width' => 60,
                'height' => 60,
                'alignment' => Jc::CENTER,
            ]);
        } catch (Exception $e) {
            $table->addCell(Converter::cmToTwip(4))->addText('[Gambar rusak]');
        }
    } else {
        $table->addCell(Converter::cmToTwip(4))->addText('-');
    }
}

// Output file ke browser
$writer = IOFactory::createWriter($phpWord, 'Word2007');
$writer->save('php://output');
exit;
