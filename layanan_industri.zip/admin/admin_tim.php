<?php
session_start();
require '../db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Tambah data tim
if (isset($_POST['submit'])) {
    $nama = $_POST['nama'];
    $jabatan = $_POST['jabatan'];
    $foto_name = $_FILES['foto']['name'];
    $foto_tmp = $_FILES['foto']['tmp_name'];
    $target_dir = "static/img/";

    if ($foto_name) {
        if (move_uploaded_file($foto_tmp, $target_dir . $foto_name)) {
            $stmt = $conn->prepare("INSERT INTO tim (nama, jabatan, foto) VALUES (?, ?, ?)");
            $stmt->bind_param("sss", $nama, $jabatan, $foto_name);
            $stmt->execute();
            $stmt->close();
        } else {
            echo "Gagal upload foto.";
        }
    }
    header("Location: admin_tim.php");
    exit();
}

// Hapus data tim
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $result = mysqli_query($conn, "SELECT foto FROM tim WHERE id = $id");
    $row = mysqli_fetch_assoc($result);
    if ($row && file_exists("static/img/" . $row['foto'])) {
        unlink("static/img/" . $row['foto']);
    }
    mysqli_query($conn, "DELETE FROM tim WHERE id = $id");
    header("Location: admin_tim.php");
    exit();
}

// Ambil data untuk diedit
$edit_mode = false;
if (isset($_GET['edit'])) {
    $edit_mode = true;
    $id_edit = intval($_GET['edit']);
    $edit_data = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM tim WHERE id = $id_edit"));
}

// Proses update
if (isset($_POST['update'])) {
    $id = intval($_POST['id']);
    $nama = $_POST['nama'];
    $jabatan = $_POST['jabatan'];

    if (!empty($_FILES['foto']['name'])) {
        $foto_name = $_FILES['foto']['name'];
        $foto_tmp = $_FILES['foto']['tmp_name'];
        move_uploaded_file($foto_tmp, "static/img/" . $foto_name);
        $query = "UPDATE tim SET nama = ?, jabatan = ?, foto = ? WHERE id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("sssi", $nama, $jabatan, $foto_name, $id);
    } else {
        $query = "UPDATE tim SET nama = ?, jabatan = ? WHERE id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("ssi", $nama, $jabatan, $id);
    }

    $stmt->execute();
    $stmt->close();
    header("Location: admin_tim.php");
    exit();
}

$result = mysqli_query($conn, "SELECT * FROM tim ORDER BY id ASC");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Input Tim</title>
    <link rel="stylesheet" href="static/admin_tim.css">
</head>
<body>
<div class="main-content">

    <!-- Tombol kembali ke dashboard -->
    <a href="index.php" style="display: inline-block; margin-bottom: 20px; background-color: #1e3a8a; color: white; padding: 8px 16px; border-radius: 6px; text-decoration: none;">← Kembali ke Dashboard</a>

    <h2><?= $edit_mode ? "Edit Data Tim" : "Input Data Tim" ?></h2>

    <form method="post" enctype="multipart/form-data">
        <input type="hidden" name="id" value="<?= $edit_data['id'] ?? '' ?>">
        <input type="text" name="nama" placeholder="Nama" required value="<?= $edit_data['nama'] ?? '' ?>"><br>
        <input type="text" name="jabatan" placeholder="Jabatan" required value="<?= $edit_data['jabatan'] ?? '' ?>"><br>
        <input type="file" name="foto" accept="image/*" <?= $edit_mode ? '' : 'required' ?>><br>
        <?php if ($edit_mode): ?>
            <button type="submit" name="update">Update</button>
            <a href="admin_tim.php">Batal</a>
        <?php else: ?>
            <button type="submit" name="submit">Simpan</button>
        <?php endif; ?>
    </form>

    <h3>Daftar Tim</h3>
    <table border="1" cellpadding="8">
        <tr>
            <th>No</th>
            <th>Nama</th>
            <th>Jabatan</th>
            <th>Foto</th>
            <th>Aksi</th>
        </tr>
        <?php $no = 1; while ($row = mysqli_fetch_assoc($result)): ?>
            <tr>
                <td><?= $no++ ?></td>
                <td><?= htmlspecialchars($row['nama']) ?></td>
                <td><?= htmlspecialchars($row['jabatan']) ?></td>
                <td><img src="static/img/<?= htmlspecialchars($row['foto']) ?>" width="60"></td>
                <td>
                    <a href="admin_tim.php?edit=<?= $row['id'] ?>">Edit</a> |
                    <a href="admin_tim.php?delete=<?= $row['id'] ?>" onclick="return confirm('Yakin ingin menghapus data ini?')">Hapus</a>
                </td>
            </tr>
        <?php endwhile; ?>
    </table>
</div>
</body>
</html>
